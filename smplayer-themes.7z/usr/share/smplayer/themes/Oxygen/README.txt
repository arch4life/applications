Icons taken from http://www.gnome-look.org/content/show.php/Oxygen+Refit+%5BIcons%5D?content=64589
License: LGPL

Icon theme created for SMPlayer by Ricardo Villalba <rvm@users.sourceforge.net>

Theme modified by Dariusz Jakoniuk <pipaceliny@interia.pl> using some
of the original Oxygen icons (dual license: Creative Common 
Attribution-ShareAlike 3.0 License or the GNU Library General Public License).
