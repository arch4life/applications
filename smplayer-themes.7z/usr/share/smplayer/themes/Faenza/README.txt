Faenza icon theme for SMPlayer

Icons taken from http://qt-apps.org/content/show.php/smplayer-theme-faenza?content=156022
License: GPL

Icon theme created for SMPlayer by tcl
