Tango icon theme for smplayer
<anyr@tut.by>

Icons from: http://tango.freedesktop.org/Tango_Desktop_Project
License: Creative Commons Attribution Share-Alike license
