Original based on icon theme created for SMPlayer by Ricardo Villalba <rvm@users.sourceforge.net>

Theme modified by Ralsa Marsh <ralsa@autistici.org> using some
of the original Oxygen icons (dual license: Creative Common 
Attribution-ShareAlike 3.0 License or the GNU Library General Public License).
