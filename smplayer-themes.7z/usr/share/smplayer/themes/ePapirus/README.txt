------------------------ SMPLAYER THEME ePAPIRUS ------------------------
AUTHOR:
Alexey Varfolomeev
https://github.com/PapirusDevelopmentTeam
