Breeze theme is created by NitruxSA

Icons are designed and developed by Uri Herrera <uri_herrera@nitrux.in> Andreas Kainz <kainz.a@gmail.com> and its contributors.

Icons are licensed under the LGPLv3 and are taken from https://github.com/NitruxSA/plasma-next-icons.
