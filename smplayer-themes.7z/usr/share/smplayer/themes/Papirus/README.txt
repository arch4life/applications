------------------------ SMPLAYER THEME PAPIRUS ------------------------
AUTHOR:
Alexey Varfolomeev
https://github.com/PapirusDevelopmentTeam
