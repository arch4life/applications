=========================
ilGaspa's SILK icon theme
=========================

I've put togheter this little icon theme wich I hope you like :-) It's
aim is to be cute, user-friendly and beautiful, whilst not changing
anything wich isn't a button or menu label icon. I've only put togheter
the pack, all the credits for icon graphics goes to FamFamFam
(http://www.famfamfam.com/lab/icons/silk/) ^_^ I won't have much time to
update this, so I give it as a gift to the community: if anyone wants to
keep it up to date, fell free to do so, you've my blessing :-)

ilGaspa (ilgaspa at email dot it)

License: Creative Commons Attribution 2.5 License
